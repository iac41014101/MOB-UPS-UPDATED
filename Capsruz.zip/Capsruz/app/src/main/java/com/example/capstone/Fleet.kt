package com.example.capstone

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button

class Fleet : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_fleet)

        // Apply padding to accommodate system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set up the "BACK" button to navigate to Customer_Service.kt
        val backButton = findViewById<Button>(R.id.button3)
        backButton.setOnClickListener {
            val intent = Intent(this, Customer_Service::class.java)
            startActivity(intent)
        }

        // Set up the "SAVE CHANGES" button to navigate to heatmap.kt
        val saveChangesButton = findViewById<Button>(R.id.button4)
        saveChangesButton.setOnClickListener {
            val intent = Intent(this, truckingvendor::class.java)
            startActivity(intent)
        }
    }
}

package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Customer_Service : AppCompatActivity() {
    private lateinit var backButton: Button
    private lateinit var submitButton: Button
    private lateinit var customerNameInput: EditText
    private lateinit var itemsInput: EditText
    private lateinit var pickupInput: EditText
    private lateinit var dropoffInput: EditText
    private lateinit var timeInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_service)

        initializeViews()
        setupClickListeners()
    }

    private fun initializeViews() {
        backButton = findViewById(R.id.backButton)
        submitButton = findViewById(R.id.submitButton)
        customerNameInput = findViewById(R.id.customerNameInput)
        itemsInput = findViewById(R.id.itemsInput)
        pickupInput = findViewById(R.id.pickupInput)
        dropoffInput = findViewById(R.id.dropoffInput)
        timeInput = findViewById(R.id.timeInput)
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            navigateToHomepage()
        }

        submitButton.setOnClickListener {
            if (validateInputs()) {
                submitBooking()
            }
        }
    }

    private fun validateInputs(): Boolean {
        val inputs = listOf(
            customerNameInput to "Please enter customer name",
            itemsInput to "Please specify items",
            pickupInput to "Please enter pickup location",
            dropoffInput to "Please enter dropoff location",
            timeInput to "Please specify time and day"
        )

        for ((input, message) in inputs) {
            if (input.text.toString().trim().isEmpty()) {
                input.error = message
                return false
            }
        }
        return true
    }

    private fun submitBooking() {
        // Display confirmation toast
        Toast.makeText(this, "Booking submitted successfully!", Toast.LENGTH_SHORT).show()

        // Navigate to Fleet.kt
        startActivity(Intent(this, Fleet::class.java))
        finish()
    }

    private fun navigateToHomepage() {
        startActivity(Intent(this, Homepage::class.java))
        finish()
    }
}
